CREATE PROCEDURE `cat_insert_sp`()
  BEGIN
	#Routine body goes here...
DECLARE x TINYINT DEFAULT 1;
DECLARE y TINYINT DEFAULT 1;

WHILE x<43
DO


WHILE y<9
DO

INSERT INTO yhq_cat_post_relationships(post_id,cat_id) VALUES(x,y);

SET y=y+1; 
END WHILE ; 


SET y=1; 
SET x=x+1; 
END WHILE ; 
commit; 

END